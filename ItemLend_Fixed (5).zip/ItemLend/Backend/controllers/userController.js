// controllers/userController.js
const User = require('../models/User');
const Wallet = require('../models/Wallet');
const Loan = require('../models/Loan');
const UserBadge = require('../models/UserBadge');
const Badge = require('../models/Badge');
const Transaction = require('../models/Transaction');
const CreditScoreService = require('../services/creditScoreService');
const logger = require('../utils/logger');
const fs = require('fs');
const path = require('path');

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
const getProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user.id)
            .select('-password')
            .lean();

        const wallet = await Wallet.findOne({ user: user._id }).lean();

        // Get active loans count
        const activeLoans = await Loan.countDocuments({
            borrower: user._id,
            status: 'active'
        });

        // Get badges count
        const badges = await UserBadge.countDocuments({
            user: user._id
        });

        res.json({
            success: true,
            data: {
                ...user,
                wallet,
                stats: {
                    activeLoans,
                    badges,
                    totalLent: user.totalLent,
                    totalBorrowed: user.totalBorrowed
                }
            }
        });
    } catch (error) {
        logger.error('Get profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get profile',
            error: error.message
        });
    }
};

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
const updateProfile = async (req, res) => {
    try {
        const { name, lendingCapacity } = req.body;
        const updateData = {};

        if (name) updateData.name = name;
        if (lendingCapacity !== undefined) {
            // Validate lending capacity
            if (lendingCapacity < 0 || lendingCapacity > 100000) {
                return res.status(400).json({
                    success: false,
                    message: 'Lending capacity must be between 0 and 100000'
                });
            }
            updateData.lendingCapacity = lendingCapacity;
        }

        const user = await User.findByIdAndUpdate(
            req.user.id,
            updateData,
            { new: true, runValidators: true }
        ).select('-password');

        res.json({
            success: true,
            data: user,
            message: 'Profile updated successfully'
        });
    } catch (error) {
        logger.error('Update profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update profile',
            error: error.message
        });
    }
};

// @desc    Upload & auto-verify KYC via OCR
// @route   POST /api/users/kyc
// @access  Private
const uploadKYC = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: 'Please upload your student ID card' });
        }

        const user = await User.findById(req.user.id);

        // Pre-process image with sharp for better OCR accuracy.
        // Greyscale + normalise contrast + sharpen dramatically improves Tesseract
        // results on photos of cards that have shadows, angles, or low contrast.
        let ocrInputPath = req.file.path;
        const processedPath = req.file.path + '_processed.png';
        try {
            const sharp = require('sharp');
            await sharp(req.file.path)
                .greyscale()
                .normalise()
                .sharpen({ sigma: 1.5 })
                .png()
                .toFile(processedPath);
            ocrInputPath = processedPath;
        } catch (sharpErr) {
            logger.warn('sharp pre-processing failed, using raw file:', sharpErr.message);
        }

        // Run Tesseract OCR on the pre-processed image.
        let ocrText = '';
        let ocrAvailable = false;
        try {
            const Tesseract = require('tesseract.js');
            ocrAvailable = true;
            const { data: { text } } = await Tesseract.recognize(ocrInputPath, 'eng', {
                logger: () => {}
            });
            ocrText = (text || '').toUpperCase().trim();
            logger.info(`KYC OCR extracted ${ocrText.length} chars for user ${req.user.id}`);
        } catch (ocrErr) {
            logger.warn('OCR unavailable or failed (will pend for manual review):', ocrErr.message);
            ocrAvailable = false;
        } finally {
            // Clean up the pre-processed temp file
            try {
                if (ocrInputPath !== req.file.path && fs.existsSync(processedPath)) {
                    fs.unlinkSync(processedPath);
                }
            } catch (_) {}
        }

        // ── University / school detection ────────────────────────────────────
        // Tesseract reads line-by-line, so "Mahindra\nUniversity" becomes
        // "MAHINDRA\nUNIVERSITY" after uppercasing — NOT "MAHINDRA UNIVERSITY"
        // with a space. We must collapse all whitespace before matching.
        const ocrFlat = ocrText.replace(/\s+/g, ' '); // collapse newlines/tabs to single space

        // Primary: institution name (with and without space, as OCR varies)
        const MU_NAME_KEYWORDS = [
            'MAHINDRA UNIVERSITY',
            'MAHINDRAUNIVERSITY',
            'MU HYDERABAD',
        ];
        // Secondary: school names printed on the card — any one is enough
        // Sources: Wikipedia + official MU site (5 schools + Hotel Management)
        const MU_SCHOOL_KEYWORDS = [
            'ECOLE CENTRALE',          // École Centrale School of Engineering
            'COLE CENTRALE',           // OCR often drops the accent E
            'SCHOOL OF ENGINEERING',
            'SCHOOL OF LAW',
            'SCHOOL OF MANAGEMENT',
            'SCHOOL OF EDUCATION',
            'SCHOOL OF MEDIA',
            'SCHOOL OF HOTEL',
            'INDIRA MAHINDRA',         // Indira Mahindra School of Education
        ];
        // Tagline that appears on every MU card
        const MU_TAGLINE_KEYWORDS = [
            'GLOBAL THINKERS',
            'ENGAGED LEADERS',
        ];

        let universityDetected = null; // null = couldn't determine (too little text)
        if (ocrFlat.length > 20) {
            const nameMatch   = MU_NAME_KEYWORDS.some(k => ocrFlat.includes(k));
            const schoolMatch  = MU_SCHOOL_KEYWORDS.some(k => ocrFlat.includes(k));
            const taglineMatch = MU_TAGLINE_KEYWORDS.some(k => ocrFlat.includes(k));
            universityDetected = nameMatch || schoolMatch || taglineMatch;
        }

        // Note: we intentionally do NOT hard-reject when keywords are missing.
        // Real phone photos of ID cards often have logo artifacts, glare, or shadows
        // that cause OCR to produce garbled text failing keyword matching.
        // Instead: auto-verify when keywords ARE found, manual review when not.

        // Extract Student ID from OCR text (use ocrFlat so newlines don't break patterns)
        let extractedStudentId = null;
        if (ocrFlat.length > 0) {
            const idPatterns = [
                // MU format: SE23UCSE078, SE24UCS001, etc.
                /\b([A-Z]{1,3}\d{2}[A-Z]{2,5}\d{3,6})\b/,
                // Generic roll: 23UCSE078
                /\b(\d{2}[A-Z]{2,5}\d{3,6})\b/,
                // Labelled: "ID No.: SE23UCSE078" or "ID No : SE23UCSE078"
                /(?:ID|ROLL|REG|STUDENT\s*(?:ID|NO))[\s.:]*([A-Z0-9]{6,15})/,
                // Fallback: two letters + 7-10 digits
                /\b([A-Z]{2}\d{7,10})\b/
            ];
            for (const pat of idPatterns) {
                const m = ocrFlat.match(pat);
                if (m) { extractedStudentId = m[1]; break; }
            }
        }

        // Extract student name from OCR text
        let extractedName = null;
        if (ocrFlat.length > 0) {
            const namePatterns = [
                // "Name : ISHANI SINGH" — capture 1-4 ALL-CAPS words, stop before next field label
                /NAME\s*[:\-]\s*((?:[A-Z]+\s*){1,4})(?=\s*(?:ID|BLOOD|ROLL|REG|SCHOOL|DEPT|DOB))/,
                /STUDENT NAME\s*[:\-]\s*((?:[A-Z]+\s*){1,4})(?=\s*(?:ID|BLOOD|ROLL|REG|SCHOOL|DEPT|DOB))/,
                // Fallback: up to 3 words after NAME:
                /NAME\s*[:\-]\s*([A-Z]+(?:\s+[A-Z]+){0,2})/,
                /(?:MR|MS|DR)[.\s]+([A-Z]+(?:\s+[A-Z]+){0,3})/
            ];
            for (const pat of namePatterns) {
                const m = ocrFlat.match(pat);
                if (m) { extractedName = m[1].trim(); break; }
            }
        }

        // Duplicate student ID check.
        // This is the application-level guard; User.studentId also has a DB-level
        // unique+sparse index as the final safety net.
        if (extractedStudentId) {
            const duplicate = await User.findOne({
                studentId: extractedStudentId,
                _id: { $ne: user._id }
            });
            if (duplicate) {
                return res.status(400).json({
                    success: false,
                    message: 'This student ID is already linked to another account. Each student can only have one account.'
                });
            }
        }

        // Delete previous KYC document if one existed
        if (user.kycDocument) {
            try {
                const oldPath = path.join(__dirname, '..', user.kycDocument);
                if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
            } catch (_) {}
        }

        // Auto-verify only if OCR worked AND found MU-specific keywords
        const autoVerified = ocrAvailable && ocrFlat.length > 50 && universityDetected === true;

        user.kycDocument      = req.file.path;
        user.isKYCVerified    = autoVerified;
        if (extractedStudentId) user.studentId = extractedStudentId;
        if (extractedName)      user.kycExtractedName = extractedName;
        if (universityDetected) user.kycUniversity = 'Mahindra University';
        await user.save();

        let message;
        if (autoVerified) {
            message = `\u2705 eKYC verified! ${extractedStudentId ? `Student ID: ${extractedStudentId}` : 'Mahindra University ID confirmed.'}`;
        } else if (!ocrAvailable) {
            message = '\uD83D\uDCC4 Document uploaded successfully. An admin will verify your ID manually \u2014 this usually takes less than 24 hours.';
        } else if (ocrFlat.length < 50) {
            message = '\uD83D\uDCC4 Document uploaded. The image was unclear for automatic reading \u2014 an admin will verify manually.';
        } else {
            message = '\uD83D\uDCC4 Document uploaded. Pending admin verification.';
        }

        res.json({
            success: true,
            data: { isKYCVerified: autoVerified, studentId: extractedStudentId, extractedName, universityDetected, message }
        });
    } catch (error) {
        logger.error('KYC upload error:', error);
        res.status(500).json({ success: false, message: 'Failed to process KYC document: ' + error.message });
    }
};

// @desc    Get credit score details
// @route   GET /api/users/credit-score
// @access  Private
const getCreditScore = async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        
        // Calculate projected score
        const projectedScore = await CreditScoreService.calculateScore(user._id);
        
        // Get score factors
        const factors = {
            timelyRepayments: CreditScoreService.evaluateTimelyRepayments(user),
            loanPerformance: CreditScoreService.evaluateLoanPerformance(user),
            lendingReliability: CreditScoreService.evaluateLendingReliability(user),
            accountAge: CreditScoreService.evaluateAccountAge(user),
            transactionVolume: CreditScoreService.evaluateTransactionVolume(user)
        };

        // Get borrowing limit
        const borrowingLimit = CreditScoreService.getBorrowingLimit(user.creditScore);
        
        // Get interest rate
        const interestRate = CreditScoreService.getInterestRate(user.creditScore);

        res.json({
            success: true,
            data: {
                currentScore: user.creditScore,
                projectedScore,
                factors,
                borrowingLimit,
                interestRate,
                history: {
                    timelyRepayments: user.timelyRepayments,
                    lateRepayments: user.lateRepayments
                }
            }
        });
    } catch (error) {
        logger.error('Get credit score error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get credit score',
            error: error.message
        });
    }
};

// @desc    Get borrowing history
// @route   GET /api/users/history/borrowing
// @access  Private
const getBorrowingHistory = async (req, res) => {
    try {
        const { page = 1, limit = 10 } = req.query;
        const skip = (page - 1) * limit;

        const loans = await Loan.find({ borrower: req.user.id })
            .populate('lender', 'name email')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(parseInt(limit))
            .lean();

        const total = await Loan.countDocuments({ borrower: req.user.id });

        // Calculate statistics
        const stats = {
            totalBorrowed: loans.reduce((sum, loan) => sum + loan.principal, 0),
            totalRepaid: loans.reduce((sum, loan) => sum + loan.amountPaid, 0),
            activeLoans: loans.filter(l => l.status === 'active').length,
            completedLoans: loans.filter(l => l.status === 'repaid').length,
            defaultedLoans: loans.filter(l => l.status === 'defaulted').length
        };

        res.json({
            success: true,
            data: loans,
            stats,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error('Get borrowing history error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get borrowing history',
            error: error.message
        });
    }
};

// @desc    Get lending history
// @route   GET /api/users/history/lending
// @access  Private
const getLendingHistory = async (req, res) => {
    try {
        const { page = 1, limit = 10 } = req.query;
        const skip = (page - 1) * limit;

        const loans = await Loan.find({ lender: req.user.id })
            .populate('borrower', 'name email creditScore')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(parseInt(limit))
            .lean();

        const total = await Loan.countDocuments({ lender: req.user.id });

        // Calculate ROI
        const stats = {
            totalLent: loans.reduce((sum, loan) => sum + loan.principal, 0),
            totalReceived: loans.reduce((sum, loan) => sum + loan.amountPaid, 0),
            activeLoans: loans.filter(l => l.status === 'active').length,
            completedLoans: loans.filter(l => l.status === 'repaid').length,
            defaultedLoans: loans.filter(l => l.status === 'defaulted').length,
            totalInterest: loans.reduce((sum, loan) => {
                if (loan.status === 'repaid') {
                    return sum + (loan.totalRepayable - loan.principal);
                }
                return sum;
            }, 0)
        };

        stats.roi = stats.totalLent > 0 
            ? ((stats.totalReceived - stats.totalLent) / stats.totalLent * 100).toFixed(2)
            : 0;

        res.json({
            success: true,
            data: loans,
            stats,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error('Get lending history error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get lending history',
            error: error.message
        });
    }
};

// @desc    Get user badges
// @route   GET /api/users/badges
// @access  Private
const getBadges = async (req, res) => {
    try {
        const userBadges = await UserBadge.find({ user: req.user.id })
            .populate('badge')
            .sort({ earnedAt: -1 });

        // Group by category
        const grouped = userBadges.reduce((acc, ub) => {
            const category = ub.badge.category;
            if (!acc[category]) {
                acc[category] = [];
            }
            acc[category].push(ub);
            return acc;
        }, {});

        res.json({
            success: true,
            data: {
                total: userBadges.length,
                grouped,
                recent: userBadges.slice(0, 5)
            }
        });
    } catch (error) {
        logger.error('Get badges error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get badges',
            error: error.message
        });
    }
};

// @desc    Get user stats
// @route   GET /api/users/stats
// @access  Private
const getUserStats = async (req, res) => {
    try {
        const userId = req.user.id;

        // Get wallet
        const wallet = await Wallet.findOne({ user: userId });

        // Get loan stats
        const loanStats = await Loan.aggregate([
            { $match: { borrower: mongoose.Types.ObjectId(userId) } },
            {
                $group: {
                    _id: '$status',
                    count: { $sum: 1 },
                    totalAmount: { $sum: '$principal' }
                }
            }
        ]);

        // Get transaction stats
        const transactionStats = await Transaction.aggregate([
            { 
                $match: { 
                    $or: [
                        { fromUser: mongoose.Types.ObjectId(userId) },
                        { toUser: mongoose.Types.ObjectId(userId) }
                    ]
                }
            },
            {
                $group: {
                    _id: '$type',
                    count: { $sum: 1 },
                    totalAmount: { $sum: '$amount' }
                }
            }
        ]);

        // Get streak info
        const streak = await calculateStreak(userId);

        res.json({
            success: true,
            data: {
                wallet: {
                    balance: wallet.balance,
                    lockedBalance: wallet.lockedBalance,
                    availableBalance: wallet.availableBalance
                },
                loans: loanStats,
                transactions: transactionStats,
                streak,
                tier: req.user.tier,
                creditScore: req.user.creditScore
            }
        });
    } catch (error) {
        logger.error('Get user stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get user stats',
            error: error.message
        });
    }
};

// Helper function to calculate streak
const calculateStreak = async (userId) => {
    const loans = await Loan.find({
        borrower: userId,
        status: 'repaid'
    }).sort({ completedDate: -1 });

    if (loans.length === 0) {
        return { current: 0, longest: 0 };
    }

    let currentStreak = 1;
    let longestStreak = 1;
    let previousDate = loans[0].completedDate;

    for (let i = 1; i < loans.length; i++) {
        const daysDiff = Math.abs((loans[i].completedDate - previousDate) / (1000 * 60 * 60 * 24));
        
        if (daysDiff <= 7) { // Within a week
            currentStreak++;
            longestStreak = Math.max(longestStreak, currentStreak);
        } else {
            currentStreak = 1;
        }
        
        previousDate = loans[i].completedDate;
    }

    return { current: currentStreak, longest: longestStreak };
};

module.exports = {
    getProfile,
    updateProfile,
    uploadKYC,
    getCreditScore,
    getBorrowingHistory,
    getLendingHistory,
    getBadges,
    getUserStats
};