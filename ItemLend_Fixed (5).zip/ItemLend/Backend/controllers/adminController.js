const User = require('../models/User');
const Loan = require('../models/Loan');
const LoanRequest = require('../models/LoanRequest');
const Transaction = require('../models/Transaction');
const Wallet = require('../models/Wallet');
const LoginAttempt = require('../models/LoginAttempt');
const logger = require('../utils/logger');
const CreditScoreService = require('../services/creditScoreService');
const mongoose = require('mongoose');

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private/Admin
const getAllUsers = async (req, res) => {
    try {
        const { page = 1, limit = 10, search, status, verified } = req.query;
        const skip = (page - 1) * limit;

        // Build query
        const query = {};
        
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } }
            ];
        }
        
        if (status === 'active') {
            query.isActive = true;
        } else if (status === 'inactive') {
            query.isActive = false;
        }
        
        if (verified === 'true') {
            query.isKYCVerified = true;
        } else if (verified === 'false') {
            query.isKYCVerified = false;
        }

        const users = await User.find(query)
            .select('-password')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(parseInt(limit))
            .lean();

        // Get wallet balances for users
        const userIds = users.map(u => u._id);
        const wallets = await Wallet.find({ user: { $in: userIds } }).lean();
        
        const walletMap = {};
        wallets.forEach(w => {
            walletMap[w.user.toString()] = w;
        });

        // Enhance users with wallet data
        const enhancedUsers = users.map(user => ({
            ...user,
            walletBalance: walletMap[user._id.toString()]?.balance || 0,
            lockedBalance: walletMap[user._id.toString()]?.lockedBalance || 0
        }));

        const total = await User.countDocuments(query);

        // Get statistics
        const stats = {
            totalUsers: await User.countDocuments(),
            verifiedUsers: await User.countDocuments({ isKYCVerified: true }),
            activeUsers: await User.countDocuments({ isActive: true }),
            adminCount: await User.countDocuments({ role: 'admin' })
        };

        res.json({
            success: true,
            data: enhancedUsers,
            stats,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / limit)
            }
        });

    } catch (error) {
        logger.error('Get all users error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get users',
            error: error.message
        });
    }
};

// @desc    Get user details by ID
// @route   GET /api/admin/users/:id
// @access  Private/Admin
const getUserDetails = async (req, res) => {
    try {
        const user = await User.findById(req.params.id)
            .select('-password')
            .lean();

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Get wallet
        const wallet = await Wallet.findOne({ user: user._id }).lean();

        // Get loan statistics
        const loanStats = await Loan.aggregate([
            { $match: { borrower: mongoose.Types.ObjectId(req.params.id) } },
            {
                $group: {
                    _id: '$status',
                    count: { $sum: 1 },
                    totalAmount: { $sum: '$principal' }
                }
            }
        ]);

        // Get recent transactions
        const recentTransactions = await Transaction.find({
            $or: [
                { fromUser: user._id },
                { toUser: user._id }
            ]
        })
        .populate('fromUser', 'name email')
        .populate('toUser', 'name email')
        .sort({ createdAt: -1 })
        .limit(10);

        // Get login attempts
        const loginAttempts = await LoginAttempt.find({ email: user.email })
            .sort({ createdAt: -1 })
            .limit(5);

        res.json({
            success: true,
            data: {
                user,
                wallet: wallet || { balance: 0, lockedBalance: 0 },
                loanStats,
                recentTransactions,
                loginAttempts
            }
        });

    } catch (error) {
        logger.error('Get user details error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get user details',
            error: error.message
        });
    }
};

// @desc    Freeze user account
// @route   POST /api/admin/users/:id/freeze
// @access  Private/Admin
const freezeUser = async (req, res) => {
    try {
        const { reason } = req.body;

        const user = await User.findById(req.params.id);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        if (user.role === 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Cannot freeze admin accounts'
            });
        }

        user.isActive = false;
        await user.save();

        logger.warn(`User account frozen: ${user.email} by admin ${req.user.id}. Reason: ${reason}`);

        res.json({
            success: true,
            message: `User ${user.name} has been frozen successfully`,
            data: {
                userId: user._id,
                email: user.email,
                status: 'frozen'
            }
        });

    } catch (error) {
        logger.error('Freeze user error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to freeze user',
            error: error.message
        });
    }
};

// @desc    Activate user account
// @route   POST /api/admin/users/:id/activate
// @access  Private/Admin
const activateUser = async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        user.isActive = true;
        await user.save();

        logger.info(`User account activated: ${user.email} by admin ${req.user.id}`);

        res.json({
            success: true,
            message: `User ${user.name} has been activated successfully`,
            data: {
                userId: user._id,
                email: user.email,
                status: 'active'
            }
        });

    } catch (error) {
        logger.error('Activate user error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to activate user',
            error: error.message
        });
    }
};

// @desc    Get all transactions
// @route   GET /api/admin/transactions
// @access  Private/Admin
const getAllTransactions = async (req, res) => {
    try {
        const { page = 1, limit = 20, type, startDate, endDate } = req.query;
        const skip = (page - 1) * limit;

        const query = {};
        
        if (type) {
            query.type = type;
        }
        
        if (startDate || endDate) {
            query.createdAt = {};
            if (startDate) query.createdAt.$gte = new Date(startDate);
            if (endDate) query.createdAt.$lte = new Date(endDate);
        }

        const transactions = await Transaction.find(query)
            .populate('fromUser', 'name email')
            .populate('toUser', 'name email')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(parseInt(limit));

        const total = await Transaction.countDocuments(query);

        // Get summary stats
        const summary = await Transaction.aggregate([
            {
                $group: {
                    _id: null,
                    totalAmount: { $sum: '$amount' },
                    avgAmount: { $avg: '$amount' },
                    count: { $sum: 1 }
                }
            }
        ]);

        res.json({
            success: true,
            data: transactions,
            summary: summary[0] || { totalAmount: 0, avgAmount: 0, count: 0 },
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / limit)
            }
        });

    } catch (error) {
        logger.error('Get all transactions error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get transactions',
            error: error.message
        });
    }
};

// @desc    Get system statistics
// @route   GET /api/admin/stats
// @access  Private/Admin
const getSystemStats = async (req, res) => {
    try {
        // User statistics
        const userStats = await User.aggregate([
            {
                $group: {
                    _id: null,
                    total: { $sum: 1 },
                    verified: { $sum: { $cond: ['$isKYCVerified', 1, 0] } },
                    active: { $sum: { $cond: ['$isActive', 1, 0] } },
                    avgCreditScore: { $avg: '$creditScore' }
                }
            }
        ]);

        // Loan statistics
        const loanStats = await Loan.aggregate([
            {
                $group: {
                    _id: '$status',
                    count: { $sum: 1 },
                    totalAmount: { $sum: '$principal' },
                    totalInterest: { $sum: '$interestAccrued' }
                }
            }
        ]);

        // Transaction statistics
        const transactionStats = await Transaction.aggregate([
            {
                $group: {
                    _id: '$type',
                    count: { $sum: 1 },
                    totalAmount: { $sum: '$amount' }
                }
            }
        ]);

        // Points in circulation
        const walletStats = await Wallet.aggregate([
            {
                $group: {
                    _id: null,
                    totalPoints: { $sum: '$balance' },
                    lockedPoints: { $sum: '$lockedBalance' },
                    avgBalance: { $avg: '$balance' }
                }
            }
        ]);

        // Recent activity
        const recentActivity = await Transaction.find()
            .populate('fromUser', 'name email')
            .populate('toUser', 'name email')
            .sort({ createdAt: -1 })
            .limit(10);

        res.json({
            success: true,
            data: {
                users: userStats[0] || { total: 0, verified: 0, active: 0, avgCreditScore: 500 },
                loans: loanStats,
                transactions: transactionStats,
                points: walletStats[0] || { totalPoints: 0, lockedPoints: 0, avgBalance: 0 },
                recentActivity
            }
        });

    } catch (error) {
        logger.error('Get system stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get system statistics',
            error: error.message
        });
    }
};

// @desc    Get dashboard statistics (for admin dashboard)
// @route   GET /api/admin/dashboard
// @access  Private/Admin
const getDashboardStats = async (req, res) => {
    try {
        // Get today's date range
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        // Get counts
        const [
            totalUsers,
            newUsersToday,
            pendingLoans,
            activeLoans,
            totalTransactions,
            totalPoints
        ] = await Promise.all([
            User.countDocuments(),
            User.countDocuments({ createdAt: { $gte: today, $lt: tomorrow } }),
            LoanRequest.countDocuments({ status: 'pending' }),
            Loan.countDocuments({ status: 'active' }),
            Transaction.countDocuments({ createdAt: { $gte: today, $lt: tomorrow } }),
            Wallet.aggregate([{ $group: { _id: null, total: { $sum: '$balance' } } }])
        ]);

        // Get recent loan requests
        const recentRequests = await LoanRequest.find({ status: 'pending' })
            .populate('borrower', 'name email creditScore')
            .sort({ createdAt: -1 })
            .limit(5);

        // Get high risk users
        const highRiskUsers = await User.find({ 
            creditScore: { $lt: 400 },
            isActive: true 
        })
        .select('name email creditScore')
        .limit(5);

        res.json({
            success: true,
            data: {
                overview: {
                    totalUsers,
                    newUsersToday,
                    pendingLoans,
                    activeLoans,
                    transactionsToday: totalTransactions,
                    totalPointsInCirculation: totalPoints[0]?.total || 0
                },
                recentRequests,
                highRiskUsers,
                timestamp: new Date()
            }
        });

    } catch (error) {
        logger.error('Get dashboard stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get dashboard statistics',
            error: error.message
        });
    }
};

// @desc    Get risk heatmap data
// @route   GET /api/admin/risk-heatmap
// @access  Private/Admin
const getRiskHeatmap = async (req, res) => {
    try {
        const riskData = await User.aggregate([
            {
                $group: {
                    _id: {
                        scoreRange: {
                            $switch: {
                                branches: [
                                    { case: { $lte: ['$creditScore', 400] }, then: 'High Risk' },
                                    { case: { $lte: ['$creditScore', 600] }, then: 'Medium Risk' },
                                    { case: { $lte: ['$creditScore', 750] }, then: 'Low Risk' }
                                ],
                                default: 'Excellent'
                            }
                        },
                        kycStatus: '$isKYCVerified'
                    },
                    count: { $sum: 1 }
                }
            }
        ]);

        // Get default rates
        const defaultRates = await Loan.aggregate([
            {
                $group: {
                    _id: {
                        $cond: ['$isLate', 'Late', 'On Time']
                    },
                    count: { $sum: 1 },
                    amount: { $sum: '$principal' }
                }
            }
        ]);

        res.json({
            success: true,
            data: {
                riskDistribution: riskData,
                defaultRates,
                timestamp: new Date()
            }
        });

    } catch (error) {
        logger.error('Get risk heatmap error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get risk heatmap',
            error: error.message
        });
    }
};

// @desc    Get fraud alerts
// @route   GET /api/admin/fraud-alerts
// @access  Private/Admin
const getFraudAlerts = async (req, res) => {
    try {
        // Check for multiple login attempts
        const suspiciousLogins = await LoginAttempt.find({
            attempts: { $gte: 5 },
            lockedUntil: { $ne: null }
        })
        .sort({ createdAt: -1 })
        .limit(20);

        // Check for users with multiple loan requests
        const suspiciousRequests = await LoanRequest.aggregate([
            {
                $group: {
                    _id: '$borrower',
                    count: { $sum: 1 },
                    requests: { $push: '$$ROOT' }
                }
            },
            { $match: { count: { $gte: 5 } } },
            { $sort: { count: -1 } },
            { $limit: 10 }
        ]);

        // Populate user details for suspicious requests
        const populatedRequests = await User.populate(suspiciousRequests, {
            path: '_id',
            select: 'name email creditScore'
        });

        res.json({
            success: true,
            data: {
                suspiciousLogins,
                suspiciousRequests: populatedRequests,
                timestamp: new Date()
            }
        });

    } catch (error) {
        logger.error('Get fraud alerts error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get fraud alerts',
            error: error.message
        });
    }
};

// @desc    Resolve dispute
// @route   POST /api/admin/resolve-dispute
// @access  Private/Admin
const resolveDispute = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const { loanId, resolution, action } = req.body;

        const loan = await Loan.findById(loanId)
            .populate('borrower')
            .populate('lender');

        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        // Handle different resolution actions
        switch (action) {
            case 'waive_penalty':
                loan.latePenaltyAmount = 0;
                loan.latePenaltyApplied = false;
                break;
                
            case 'adjust_interest':
                // Adjust interest logic
                break;
                
            case 'mark_as_repaid':
                loan.status = 'repaid';
                loan.completedDate = new Date();
                break;
                
            default:
                // Log the dispute
                break;
        }

        await loan.save({ session });

        // Log the dispute resolution
        logger.info(`Dispute resolved for loan ${loanId} by admin ${req.user.id}. Action: ${action}`);

        await session.commitTransaction();

        res.json({
            success: true,
            message: 'Dispute resolved successfully',
            data: loan
        });

    } catch (error) {
        await session.abortTransaction();
        logger.error('Resolve dispute error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to resolve dispute',
            error: error.message
        });
    } finally {
        session.endSession();
    }
};

// @desc    Adjust interest rates
// @route   POST /api/admin/adjust-interest
// @access  Private/Admin
const adjustInterestRates = async (req, res) => {
    try {
        const { baseRate, maxRate, minRate } = req.body;

        // This would update system-wide interest rate settings
        // For now, just log the action
        logger.info(`Interest rates adjusted by admin ${req.user.id}:`, {
            baseRate,
            maxRate,
            minRate
        });

        res.json({
            success: true,
            message: 'Interest rates updated successfully',
            data: { baseRate, maxRate, minRate }
        });

    } catch (error) {
        logger.error('Adjust interest rates error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to adjust interest rates',
            error: error.message
        });
    }
};

// @desc    Export reports
// @route   GET /api/admin/export/:type
// @access  Private/Admin
const exportReports = async (req, res) => {
    try {
        const { type } = req.params;
        const { startDate, endDate } = req.query;

        let data = [];
        let filename = '';

        switch (type) {
            case 'users':
                data = await User.find({
                    createdAt: {
                        $gte: new Date(startDate || '2020-01-01'),
                        $lte: new Date(endDate || new Date())
                    }
                }).select('-password').lean();
                filename = 'users_report.csv';
                break;

            case 'transactions':
                data = await Transaction.find({
                    createdAt: {
                        $gte: new Date(startDate || '2020-01-01'),
                        $lte: new Date(endDate || new Date())
                    }
                })
                .populate('fromUser', 'email')
                .populate('toUser', 'email')
                .lean();
                filename = 'transactions_report.csv';
                break;

            case 'loans':
                data = await Loan.find({
                    createdAt: {
                        $gte: new Date(startDate || '2020-01-01'),
                        $lte: new Date(endDate || new Date())
                    }
                })
                .populate('borrower', 'email')
                .populate('lender', 'email')
                .lean();
                filename = 'loans_report.csv';
                break;

            default:
                return res.status(400).json({
                    success: false,
                    message: 'Invalid report type'
                });
        }

        // Convert to CSV (simplified)
        const csv = convertToCSV(data);

        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
        res.send(csv);

    } catch (error) {
        logger.error('Export reports error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to export report',
            error: error.message
        });
    }
};

// Helper function to convert JSON to CSV
const convertToCSV = (data) => {
    if (!data || data.length === 0) return '';
    
    const headers = Object.keys(data[0]);
    const csvRows = [];
    
    csvRows.push(headers.join(','));
    
    for (const row of data) {
        const values = headers.map(header => {
            const value = row[header] || '';
            return `"${value.toString().replace(/"/g, '""')}"`;
        });
        csvRows.push(values.join(','));
    }
    
    return csvRows.join('\n');
};

module.exports = {
    getAllUsers,
    getUserDetails,
    freezeUser,
    activateUser,
    getAllTransactions,
    getSystemStats,
    getDashboardStats,
    getRiskHeatmap,
    getFraudAlerts,
    resolveDispute,
    adjustInterestRates,
    exportReports
};