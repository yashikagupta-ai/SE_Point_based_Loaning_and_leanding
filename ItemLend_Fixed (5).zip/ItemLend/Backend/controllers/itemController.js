// controllers/itemController.js
const ItemListing = require('../models/ItemListing');
const Wallet      = require('../models/Wallet');
const Transaction = require('../models/Transaction');
const User        = require('../models/User');
const logger      = require('../utils/logger');
const mongoose    = require('mongoose');

// ── Lender: post a new item ──────────────────────────────────────────────────
// POST /api/items
const createListing = async (req, res) => {
    try {
        const { itemName, description, category, pointsPerDay, maxDuration, condition } = req.body;

        if (!itemName || !description || !pointsPerDay) {
            return res.status(400).json({ success: false, message: 'itemName, description and pointsPerDay are required' });
        }

        const listing = await ItemListing.create({
            lender: req.user.id,
            itemName,
            description,
            category: category || 'other',
            pointsPerDay: Number(pointsPerDay),
            maxDuration:  Number(maxDuration) || 30,
            condition:    condition || 'good'
        });

        res.status(201).json({ success: true, data: listing, message: 'Item listed successfully' });
    } catch (err) {
        logger.error('Create listing error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
};

// ── Anyone: browse available items ──────────────────────────────────────────
// GET /api/items
const getListings = async (req, res) => {
    try {
        const { category, page = 1, limit = 20, mine, borrowedByMe } = req.query;
        const skip = (page - 1) * limit;

        let query = {};
        if (mine === 'true') {
            query = { lender: req.user.id };
        } else if (borrowedByMe === 'true') {
            query = { currentBorrower: req.user.id };
        } else {
            query = { status: 'available', lender: { $ne: req.user.id } };
        }

        if (category) query.category = category;

        const [listings, total] = await Promise.all([
            ItemListing.find(query)
                .populate('lender', 'name email tier')
                .populate('currentBorrower', 'name email')
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(Number(limit)),
            ItemListing.countDocuments(query)
        ]);

        res.json({ success: true, data: listings, pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / limit) } });
    } catch (err) {
        logger.error('Get listings error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
};

// ── Anyone: get single listing ───────────────────────────────────────────────
// GET /api/items/:id
const getListing = async (req, res) => {
    try {
        const listing = await ItemListing.findById(req.params.id)
            .populate('lender', 'name email tier isKYCVerified')
            .populate('currentBorrower', 'name email')
            .populate('borrowRequests.borrower', 'name email');

        if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });
        res.json({ success: true, data: listing });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
};

// ── Borrower: request to borrow ──────────────────────────────────────────────
// POST /api/items/:id/request
const requestBorrow = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
        const { message, duration } = req.body;
        const days = Number(duration) || 1;

        const listing = await ItemListing.findById(req.params.id).session(session);
        if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });

        if (listing.lender.toString() === req.user.id)
            return res.status(400).json({ success: false, message: 'You cannot borrow your own item' });

        if (listing.status !== 'available')
            return res.status(400).json({ success: false, message: 'Item is not available' });

        if (days > listing.maxDuration)
            return res.status(400).json({ success: false, message: `Max borrow duration is ${listing.maxDuration} days` });

        const totalPoints = listing.pointsPerDay * days;

        // Check borrower wallet (compute available manually — virtual may not work with sessions)
        const borrowerWallet = await Wallet.findOne({ user: req.user.id }).session(session);
        const available = borrowerWallet ? (borrowerWallet.balance - borrowerWallet.lockedBalance) : 0;
        if (!borrowerWallet || available < totalPoints)
            return res.status(400).json({ success: false, message: `Insufficient points. Need ${totalPoints} pts (you have ${available} available)` });

        // Check duplicate pending request
        const already = listing.borrowRequests.find(
            r => r.borrower.toString() === req.user.id && r.status === 'pending'
        );
        if (already) return res.status(400).json({ success: false, message: 'You already have a pending request for this item' });

        // Atomically escrow points from borrower
        await Wallet.findOneAndUpdate(
            { user: req.user.id },
            { $inc: { balance: -totalPoints, lockedBalance: totalPoints, totalSpent: totalPoints },
              $set:  { lastTransactionAt: new Date() } }
        );

        // Add borrow request to listing
        listing.borrowRequests.push({
            borrower:    req.user.id,
            message:     message || '',
            status:      'pending',
            duration:    days,
            totalPoints: totalPoints
        });
        await listing.save({ session });

        // Record escrow transaction
        await Transaction.create([{
            type:        'loan_created',
            fromUser:    req.user.id,
            toUser:      listing.lender,
            amount:      totalPoints,
            description: `Escrow for borrowing "${listing.itemName}" (${days} day${days>1?'s':''})`,
            status:      'pending',
            listingId:   listing._id,
            metadata:    new Map([['duration', String(days)]])
        }], { session });

        await session.commitTransaction();
        res.status(201).json({ success: true, message: `Request sent. ${totalPoints} pts held in escrow.` });
    } catch (err) {
        await session.abortTransaction();
        logger.error('Request borrow error:', err);
        res.status(500).json({ success: false, message: err.message });
    } finally { session.endSession(); }
};

// ── Lender: approve a borrow request ────────────────────────────────────────
// POST /api/items/:id/requests/:reqId/approve
const approveBorrow = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
        const listing = await ItemListing.findById(req.params.id).session(session);
        if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });

        if (listing.lender.toString() !== req.user.id)
            return res.status(403).json({ success: false, message: 'Only the lender can approve' });

        const request = listing.borrowRequests.id(req.params.reqId);
        if (!request) return res.status(404).json({ success: false, message: 'Borrow request not found' });
        if (request.status !== 'pending') return res.status(400).json({ success: false, message: 'Request already handled' });

        const totalPoints = (request.totalPoints || listing.pointsPerDay);

        // Atomically release escrow from borrower
        await Wallet.findOneAndUpdate(
            { user: request.borrower },
            { $inc: { lockedBalance: -totalPoints }, $set: { lastTransactionAt: new Date() } }
        );

        // Atomically pay lender
        await Wallet.findOneAndUpdate(
            { user: req.user.id },
            { $inc: { balance: totalPoints, totalEarned: totalPoints }, $set: { lastTransactionAt: new Date() } }
        );

        // Reject all other pending requests and refund their escrow
        for (const r of listing.borrowRequests) {
            if (r._id.toString() === req.params.reqId || r.status !== 'pending') continue;
            const pts = r.totalPoints || listing.pointsPerDay;
            await Wallet.findOneAndUpdate(
                { user: r.borrower },
                { $inc: { balance: pts, lockedBalance: -pts, totalSpent: -pts }, $set: { lastTransactionAt: new Date() } }
            );
            r.status = 'rejected';
            r.rejectionReason = 'Another request was approved';
        }

        // Update the approved request
        request.status     = 'approved';
        request.approvedAt = new Date();

        // Mark listing as borrowed
        listing.status          = 'borrowed';
        listing.isAvailable     = false;
        listing.currentBorrower = request.borrower;
        await listing.save({ session });

        // Update transaction status
        await Transaction.findOneAndUpdate(
            { fromUser: request.borrower, listingId: listing._id, status: 'pending' },
            { status: 'completed', description: `Payment for borrowing "${listing.itemName}"` },
            { session }
        );

        // Update user stats
        await User.findByIdAndUpdate(listing.lender,    { $inc: { totalLent:     totalPoints } }, { session });
        await User.findByIdAndUpdate(request.borrower,  { $inc: { totalBorrowed: totalPoints } }, { session });

        await session.commitTransaction();
        res.json({ success: true, message: `Approved! ${totalPoints} pts transferred to your wallet.` });
    } catch (err) {
        await session.abortTransaction();
        logger.error('Approve borrow error:', err);
        res.status(500).json({ success: false, message: err.message });
    } finally { session.endSession(); }
};

// ── Lender or Borrower: mark item as returned ────────────────────────────────
// POST /api/items/:id/return
const returnItem = async (req, res) => {
    try {
        const listing = await ItemListing.findById(req.params.id);
        if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });

        const isLender   = listing.lender.toString()          === req.user.id;
        const isBorrower = listing.currentBorrower?.toString() === req.user.id;
        if (!isLender && !isBorrower)
            return res.status(403).json({ success: false, message: 'Not authorized' });

        // Find and mark the approved request as returned
        const request = listing.borrowRequests.find(r => r.status === 'approved');
        if (request) { request.status = 'returned'; request.returnedAt = new Date(); }

        // Re-open listing
        listing.status          = 'available';
        listing.isAvailable     = true;
        listing.currentBorrower = null;

        // Update on-time returns for borrower
        if (request) {
            await User.findByIdAndUpdate(request.borrower, { $inc: { timelyRepayments: 1 } });
        }

        await listing.save();
        res.json({ success: true, message: 'Item marked as returned. Listing is available again.' });
    } catch (err) {
        logger.error('Return item error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
};

// ── Lender: reject a borrow request ─────────────────────────────────────────
// POST /api/items/:id/requests/:reqId/reject
const rejectBorrow = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
        const listing = await ItemListing.findById(req.params.id).session(session);
        if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });
        if (listing.lender.toString() !== req.user.id)
            return res.status(403).json({ success: false, message: 'Only the lender can reject' });

        const request = listing.borrowRequests.id(req.params.reqId);
        if (!request || request.status !== 'pending')
            return res.status(400).json({ success: false, message: 'Request not found or already handled' });

        const totalPoints = request.totalPoints || listing.pointsPerDay;

        // Atomically refund escrow to borrower
        await Wallet.findOneAndUpdate(
            { user: request.borrower },
            { $inc: { balance: totalPoints, lockedBalance: -totalPoints, totalSpent: -totalPoints },
              $set:  { lastTransactionAt: new Date() } }
        );

        request.status          = 'rejected';
        request.rejectedAt      = new Date();
        request.rejectionReason = req.body.reason || 'Declined by lender';
        await listing.save({ session });

        await Transaction.findOneAndUpdate(
            { fromUser: request.borrower, listingId: listing._id, status: 'pending' },
            { status: 'cancelled', description: `Refund: borrow request rejected for "${listing.itemName}"` },
            { session }
        );

        await session.commitTransaction();
        res.json({ success: true, message: 'Request rejected and points refunded.' });
    } catch (err) {
        await session.abortTransaction();
        logger.error('Reject borrow error:', err);
        res.status(500).json({ success: false, message: err.message });
    } finally { session.endSession(); }
};

// ── Lender: unlist / edit listing ───────────────────────────────────────────
// DELETE /api/items/:id  (unlist)
const unlistItem = async (req, res) => {
    try {
        const listing = await ItemListing.findById(req.params.id);
        if (!listing) return res.status(404).json({ success: false, message: 'Not found' });
        if (listing.lender.toString() !== req.user.id)
            return res.status(403).json({ success: false, message: 'Not authorized' });
        if (listing.status === 'borrowed')
            return res.status(400).json({ success: false, message: 'Cannot unlist while item is borrowed' });

        listing.status      = 'unlisted';
        listing.isAvailable = false;
        await listing.save();
        res.json({ success: true, message: 'Item unlisted.' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
};

module.exports = { createListing, getListings, getListing, requestBorrow, approveBorrow, rejectBorrow, returnItem, unlistItem };
