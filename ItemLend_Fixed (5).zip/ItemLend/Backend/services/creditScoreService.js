// services/creditScoreService.js
const User = require('../models/User');

class CreditScoreService {
    // Calculate new credit score based on user behavior
    static async calculateScore(userId) {
        const user = await User.findById(userId);
        if (!user) throw new Error('User not found');
        
        let score = user.creditScore;
        
        // Factors affecting credit score
        const factors = {
            timelyRepayments: this.evaluateTimelyRepayments(user),
            loanPerformance: this.evaluateLoanPerformance(user),
            lendingReliability: this.evaluateLendingReliability(user),
            accountAge: this.evaluateAccountAge(user),
            transactionVolume: this.evaluateTransactionVolume(user)
        };
        
        // Apply adjustments based on factors
        if (factors.timelyRepayments > 0) score += factors.timelyRepayments;
        if (factors.loanPerformance > 0) score += factors.loanPerformance;
        if (factors.lendingReliability > 0) score += factors.lendingReliability;
        if (factors.accountAge > 0) score += factors.accountAge;
        if (factors.transactionVolume > 0) score += factors.transactionVolume;
        
        // Penalties for negative behavior
        if (user.lateRepayments > 0) {
            score -= Math.min(50, user.lateRepayments * 10);
        }
        
        // Ensure score stays within bounds
        return Math.min(900, Math.max(300, Math.round(score)));
    }
    
    static evaluateTimelyRepayments(user) {
        const totalRepayments = user.timelyRepayments + user.lateRepayments;
        if (totalRepayments === 0) return 0;
        
        const ratio = user.timelyRepayments / totalRepayments;
        if (ratio >= 0.95) return 50;
        if (ratio >= 0.85) return 30;
        if (ratio >= 0.70) return 10;
        return 0;
    }
    
    static evaluateLoanPerformance(user) {
        const totalLoans = user.totalBorrowed > 0 ? 1 : 0;
        if (totalLoans === 0) return 0;
        
        // More sophisticated logic based on loan history
        return Math.min(30, Math.floor(user.totalBorrowed / 1000) * 5);
    }
    
    static evaluateLendingReliability(user) {
        if (user.totalLent === 0) return 0;
        return Math.min(40, Math.floor(user.totalLent / 2000) * 10);
    }
    
    static evaluateAccountAge(user) {
        const accountAge = Math.floor((Date.now() - user.createdAt) / (1000 * 60 * 60 * 24));
        return Math.min(30, Math.floor(accountAge / 30) * 5);
    }
    
    static evaluateTransactionVolume(user) {
        const totalTransactions = user.timelyRepayments + user.lateRepayments;
        return Math.min(20, Math.floor(totalTransactions / 5) * 2);
    }
    
    // Get interest rate based on credit score
    static getInterestRate(creditScore) {
        // Lower score = higher interest rate
        if (creditScore >= 750) return 5; // 5% APR
        if (creditScore >= 650) return 8;
        if (creditScore >= 550) return 12;
        if (creditScore >= 450) return 18;
        return 24; // Highest risk
    }
    
    // Get maximum borrowing limit based on credit score
    static getBorrowingLimit(creditScore) {
        if (creditScore >= 800) return 5000;
        if (creditScore >= 700) return 3000;
        if (creditScore >= 600) return 2000;
        if (creditScore >= 500) return 1000;
        return 500;
    }
}

module.exports = CreditScoreService;