// routes/itemRoutes.js
const express = require('express');
const router  = express.Router();
const { protect } = require('../middleware/authMiddleware');
const {
    createListing, getListings, getListing,
    requestBorrow, approveBorrow, rejectBorrow, returnItem, unlistItem
} = require('../controllers/itemController');

router.use(protect);

router.get('/',          getListings);
router.post('/',         createListing);
router.get('/:id',       getListing);
router.delete('/:id',    unlistItem);
router.post('/:id/request',                        requestBorrow);
router.post('/:id/requests/:reqId/approve',        approveBorrow);
router.post('/:id/requests/:reqId/reject',         rejectBorrow);
router.post('/:id/return',                         returnItem);

module.exports = router;
