// routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const { admin } = require('../middleware/adminMiddleware');
const {
    getAllUsers,
    getUserDetails,
    freezeUser,
    activateUser,
    getAllTransactions,
    getSystemStats,
    getRiskHeatmap,
    getFraudAlerts,
    resolveDispute,
    adjustInterestRates,
    exportReports,
    getDashboardStats
} = require('../controllers/adminController');

// All routes require admin privileges
router.use(protect, admin);

// User management
router.get('/users', getAllUsers);
router.get('/users/:id', getUserDetails);
router.post('/users/:id/freeze', freezeUser);
router.post('/users/:id/activate', activateUser);

// Transaction monitoring
router.get('/transactions', getAllTransactions);
router.get('/stats', getSystemStats);
router.get('/dashboard', getDashboardStats);

// Risk and fraud
router.get('/risk-heatmap', getRiskHeatmap);
router.get('/fraud-alerts', getFraudAlerts);

// System management
router.post('/resolve-dispute', resolveDispute);
router.post('/adjust-interest', adjustInterestRates);

// Reports
router.get('/export/:type', exportReports);

module.exports = router;