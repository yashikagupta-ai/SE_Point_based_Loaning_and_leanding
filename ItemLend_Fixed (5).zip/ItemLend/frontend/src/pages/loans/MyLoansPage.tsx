import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSelector } from 'react-redux';
import { Package, Tag, Check, X, RotateCcw, Trash2, Clock } from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { itemApi } from '@/services/api';
import type { RootState } from '@/store';
import { cn, formatDate } from '@/utils/helpers';

const statusColors: Record<string, string> = {
  available:  'bg-green-100 text-green-700',
  borrowed:   'bg-orange-100 text-orange-700',
  unlisted:   'bg-gray-100 text-gray-500',
  pending:    'bg-yellow-100 text-yellow-700',
  approved:   'bg-green-100 text-green-700',
  rejected:   'bg-red-100 text-red-600',
  returned:   'bg-blue-100 text-blue-700',
};

type Tab = 'my-items' | 'borrowing';

const MyLoansPage: React.FC = () => {
  const { user }                  = useSelector((s: RootState) => s.auth);
  const [tab, setTab]             = useState<Tab>('my-items');
  const [myItems, setMyItems]     = useState<any[]>([]);
  const [borrowing, setBorrowing] = useState<any[]>([]);
  const [loading, setLoading]     = useState(true);
  const [toast, setToast]         = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3500); };

  const loadAll = () => {
    setLoading(true);
    Promise.all([
      itemApi.getListings({ mine: true } as any).then(r => setMyItems(r.data.data || [])),
      itemApi.getListings({ borrowedByMe: true } as any).then(r => setBorrowing(r.data.data || [])),
    ]).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { loadAll(); }, []);

  const handleApprove = async (itemId: string, reqId: string) => {
    try {
      await itemApi.approveBorrow(itemId, reqId);
      showToast('Approved! Points transferred to your wallet.');
      loadAll();
    } catch (err: any) { showToast(err.response?.data?.message || 'Failed'); }
  };

  const handleReject = async (itemId: string, reqId: string) => {
    try {
      await itemApi.rejectBorrow(itemId, reqId);
      showToast('Request rejected and points refunded to borrower.');
      loadAll();
    } catch (err: any) { showToast(err.response?.data?.message || 'Failed'); }
  };

  const handleReturn = async (itemId: string) => {
    try {
      await itemApi.returnItem(itemId);
      showToast('Item marked as returned!');
      loadAll();
    } catch (err: any) { showToast(err.response?.data?.message || 'Failed'); }
  };

  const handleUnlist = async (itemId: string) => {
    if (!window.confirm('Unlist this item?')) return;
    try {
      await itemApi.unlist(itemId);
      showToast('Item unlisted.');
      loadAll();
    } catch (err: any) { showToast(err.response?.data?.message || 'Failed'); }
  };

  return (
    <Layout>
      <div className="max-w-4xl space-y-6">
        {toast && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}
            className="fixed top-20 right-4 z-50 bg-gray-900 text-white px-4 py-3 rounded-xl text-sm shadow-lg">
            {toast}
          </motion.div>
        )}

        <h1 className="text-2xl font-bold text-gray-900">My Items</h1>

        {/* Tabs */}
        <div className="flex gap-2">
          {(['my-items', 'borrowing'] as Tab[]).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={cn('px-4 py-2 rounded-xl text-sm font-medium transition-colors',
                tab === t ? 'bg-[#5B6CFF] text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50')}>
              {t === 'my-items' ? 'My Listings' : 'Items I\'m Borrowing'}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-16">
            <div className="w-10 h-10 border-4 border-[#5B6CFF] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <>
            {/* My Listings tab */}
            {tab === 'my-items' && (
              <div className="space-y-5">
                {myItems.length === 0 ? (
                  <div className="bg-white rounded-2xl p-14 border border-gray-100 text-center">
                    <Package className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                    <p className="text-gray-500">You haven't posted any items yet</p>
                    <p className="text-xs text-gray-400 mt-1">Go to Item Market → Post an Item</p>
                  </div>
                ) : myItems.map(item => {
                  const pendingRequests = (item.borrowRequests || []).filter((r: any) => r.status === 'pending');
                  return (
                    <motion.div key={item._id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                      {/* Item header */}
                      <div className="p-5 flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-bold text-gray-900">{item.itemName}</h3>
                            <span className={cn('text-xs font-semibold px-2 py-0.5 rounded-full capitalize',
                              statusColors[item.status] || 'bg-gray-100 text-gray-600')}>
                              {item.status}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500 line-clamp-1">{item.description}</p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                            <span className="flex items-center gap-1"><Tag className="w-3 h-3" />{item.pointsPerDay} pts/day</span>
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" />max {item.maxDuration}d</span>
                            <span>Posted {formatDate(item.createdAt)}</span>
                          </div>
                        </div>
                        {item.status !== 'borrowed' && (
                          <button onClick={() => handleUnlist(item._id)}
                            className="p-2 rounded-xl hover:bg-red-50 text-red-400 hover:text-red-600 transition-colors flex-shrink-0">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                        {item.status === 'borrowed' && (
                          <button onClick={() => handleReturn(item._id)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-100 text-blue-700 rounded-xl text-xs font-medium hover:bg-blue-200 transition-colors flex-shrink-0">
                            <RotateCcw className="w-3.5 h-3.5" /> Mark Returned
                          </button>
                        )}
                      </div>

                      {/* Pending borrow requests */}
                      {pendingRequests.length > 0 && (
                        <div className="border-t border-gray-50 px-5 py-4 bg-gray-50/50">
                          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
                            Borrow Requests ({pendingRequests.length})
                          </p>
                          <div className="space-y-2">
                            {pendingRequests.map((req: any) => (
                              <div key={req._id} className="bg-white rounded-xl p-3 flex items-center gap-3 border border-gray-100">
                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#5B6CFF] to-[#3FAF7D] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                                  {req.borrower?.name?.[0]?.toUpperCase() ?? '?'}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-semibold text-gray-900">{req.borrower?.name ?? 'Unknown'}</p>
                                  {req.message && <p className="text-xs text-gray-400 truncate italic">"{req.message}"</p>}
                                  <p className="text-xs text-gray-400">{formatDate(req.requestedAt)}</p>
                                </div>
                                <div className="flex gap-2 flex-shrink-0">
                                  <button onClick={() => handleReject(item._id, req._id)}
                                    className="p-1.5 rounded-lg hover:bg-red-50 text-red-400 transition-colors">
                                    <X className="w-4 h-4" />
                                  </button>
                                  <button onClick={() => handleApprove(item._id, req._id)}
                                    className="flex items-center gap-1 px-3 py-1.5 bg-[#3FAF7D] text-white rounded-lg text-xs font-medium hover:bg-[#359e6e] transition-colors">
                                    <Check className="w-3.5 h-3.5" /> Approve
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Approved/returned history */}
                      {(item.borrowRequests || []).filter((r: any) => ['approved','returned'].includes(r.status)).length > 0 && (
                        <div className="border-t border-gray-50 px-5 py-3">
                          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Borrow History</p>
                          {(item.borrowRequests || []).filter((r: any) => ['approved','returned'].includes(r.status)).map((req: any) => (
                            <div key={req._id} className="flex items-center gap-2 text-sm py-1">
                              <span className={cn('text-xs font-semibold px-2 py-0.5 rounded-full capitalize', statusColors[req.status])}>
                                {req.status}
                              </span>
                              <span className="text-gray-600">{req.borrower?.name ?? 'Unknown'}</span>
                              <span className="text-gray-400 text-xs">{req.approvedAt ? formatDate(req.approvedAt) : ''}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* Items I'm borrowing tab */}
            {tab === 'borrowing' && (
              <div className="space-y-4">
                {borrowing.length === 0 ? (
                  <div className="bg-white rounded-2xl p-14 border border-gray-100 text-center">
                    <Package className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                    <p className="text-gray-500">You're not borrowing any items right now</p>
                  </div>
                ) : borrowing.map(item => (
                  <motion.div key={item._id} className="bg-white rounded-2xl border border-gray-100 p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-bold text-gray-900">{item.itemName}</h3>
                        <p className="text-sm text-gray-500 mt-0.5">Lent by {item.lender?.name}</p>
                        <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                          <span>{item.pointsPerDay} pts/day</span>
                          <span className={cn('font-semibold px-2 py-0.5 rounded-full capitalize', statusColors.borrowed)}>
                            Currently borrowed
                          </span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </Layout>
  );
};

export default MyLoansPage;
