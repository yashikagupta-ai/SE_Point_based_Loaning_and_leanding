import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Users, AlertTriangle, BarChart2, UserCheck, UserX, RefreshCw, Clock, Package } from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { adminApi } from '@/services/api';
import { formatDate, cn } from '@/utils/helpers';

const AdminPage: React.FC = () => {
  const [overview,       setOverview]       = useState<any>(null);
  const [recentRequests, setRecentRequests] = useState<any[]>([]);
  const [highRiskUsers,  setHighRiskUsers]  = useState<any[]>([]);
  const [users,          setUsers]          = useState<any[]>([]);
  const [fraudAlerts,    setFraudAlerts]    = useState<any>(null);
  const [tab,            setTab]            = useState<'overview'|'users'|'fraud'>('overview');
  const [loading,        setLoading]        = useState(true);
  const [toast,          setToast]          = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3500); };

  const reload = () => {
    setLoading(true);
    Promise.all([
      adminApi.getDashboard().then(r => {
        const d = r.data.data;
        setOverview(d?.overview ?? {});
        setRecentRequests(d?.recentRequests ?? []);
        setHighRiskUsers(d?.highRiskUsers ?? []);
      }),
      adminApi.getUsers().then(r => setUsers(r.data.data || [])),
      adminApi.getFraudAlerts().then(r => setFraudAlerts(r.data.data)),
    ]).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { reload(); }, []);

  const handleFreeze = async (id: string) => {
    try { await adminApi.freezeUser(id); setUsers(us => us.map(u => u._id === id ? { ...u, isActive: false } : u)); showToast('User frozen'); }
    catch { showToast('Action failed'); }
  };
  const handleActivate = async (id: string) => {
    try { await adminApi.activateUser(id); setUsers(us => us.map(u => u._id === id ? { ...u, isActive: true } : u)); showToast('User activated'); }
    catch { showToast('Action failed'); }
  };

  const fraudList: any[] = fraudAlerts ? [
    ...(fraudAlerts.suspiciousLogins    ?? []).map((l: any) => ({ type: 'Suspicious Login Attempts',   severity: 'HIGH',   description: `${l.attempts} failed attempts`, createdAt: l.createdAt })),
    ...(fraudAlerts.suspiciousRequests  ?? []).map((r: any) => ({ type: 'Excessive Borrow Requests',   severity: 'MEDIUM', description: `User made ${r.count} requests`, createdAt: new Date().toISOString() })),
    ...(fraudAlerts.overdueLoans        ?? []).map((l: any) => ({ type: 'Points Not Returned',         severity: 'HIGH',   description: `${l.principal} pts overdue`,    createdAt: l.dueDate })),
  ] : [];

  if (loading) return (
    <Layout>
      <div className="flex items-center justify-center h-64">
        <div className="w-10 h-10 border-4 border-[#5B6CFF] border-t-transparent rounded-full animate-spin" />
      </div>
    </Layout>
  );

  return (
    <Layout>
      <div className="max-w-6xl space-y-6">
        {toast && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}
            className="fixed top-20 right-4 z-50 bg-gray-900 text-white px-4 py-3 rounded-xl text-sm shadow-lg">
            {toast}
          </motion.div>
        )}

        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
            <p className="text-gray-500 text-sm mt-1">Platform overview and user management</p>
          </div>
          <button onClick={reload} className="p-2 rounded-xl border border-gray-200 hover:bg-gray-100 transition-colors">
            <RefreshCw className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 bg-white rounded-2xl p-1.5 border border-gray-100 w-fit">
          {[
            { key: 'overview', label: 'Overview',     icon: BarChart2     },
            { key: 'users',    label: 'Users',         icon: Users         },
            { key: 'fraud',    label: 'Risk Alerts',   icon: AlertTriangle },
          ].map(t => (
            <button key={t.key} onClick={() => setTab(t.key as any)}
              className={cn('flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all',
                tab === t.key ? 'bg-[#5B6CFF] text-white shadow' : 'text-gray-500 hover:text-gray-700')}>
              <t.icon className="w-4 h-4" />{t.label}
            </button>
          ))}
        </div>

        {/* Overview */}
        {tab === 'overview' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                { label: 'Total Users',           value: overview?.totalUsers                ?? '—', color: 'text-blue-600',   bg: 'bg-blue-50'   },
                { label: 'New Today',              value: overview?.newUsersToday             ?? '—', color: 'text-green-600',  bg: 'bg-green-50'  },
                { label: 'Pending Requests',       value: overview?.pendingLoans              ?? '—', color: 'text-yellow-600', bg: 'bg-yellow-50' },
                { label: 'Active Borrows',         value: overview?.activeLoans               ?? '—', color: 'text-purple-600', bg: 'bg-purple-50' },
                { label: "Today's Transactions",   value: overview?.transactionsToday         ?? '—', color: 'text-orange-600', bg: 'bg-orange-50' },
                { label: 'Points in Circulation',  value: overview?.totalPointsInCirculation  ?? '—', color: 'text-[#5B6CFF]',  bg: 'bg-indigo-50' },
              ].map(({ label, value, color, bg }) => (
                <div key={label} className={cn('rounded-2xl p-4 border border-gray-100', bg)}>
                  <p className="text-xs text-gray-500">{label}</p>
                  <p className={cn('text-2xl font-bold mt-1', color)}>{value}</p>
                </div>
              ))}
            </div>

            {recentRequests.length > 0 && (
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                  <Clock className="w-5 h-5 text-[#5B6CFF]" />
                  <h3 className="font-semibold text-gray-900">Recent Borrow Requests</h3>
                </div>
                <div className="space-y-3">
                  {recentRequests.map((req: any) => (
                    <div key={req._id} className="flex items-center justify-between gap-4 p-3 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#5B6CFF] to-[#3FAF7D] flex items-center justify-center text-white text-sm font-bold">
                          {req.borrower?.name?.[0]?.toUpperCase() ?? '?'}
                        </div>
                        <div>
                          <p className="font-medium text-sm text-gray-900">{req.borrower?.name ?? 'Unknown'}</p>
                          <p className="text-xs text-gray-400">{req.purpose}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-900">{req.amount} pts</p>
                        <p className="text-xs text-gray-400">{req.duration} days</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {highRiskUsers.length > 0 && (
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <h3 className="font-semibold text-gray-900">High Risk Users</h3>
                  <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-medium">trust score &lt; 400</span>
                </div>
                <div className="space-y-3">
                  {highRiskUsers.map((u: any) => (
                    <div key={u._id} className="flex items-center justify-between p-3 bg-red-50 rounded-xl">
                      <div>
                        <p className="font-medium text-sm text-gray-900">{u.name}</p>
                        <p className="text-xs text-gray-400">{u.email}</p>
                      </div>
                      <span className="font-bold text-red-600">Score: {u.creditScore}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {/* Users */}
        {tab === 'users' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            {users.length > 0 ? (
              <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-100">
                      <tr>
                        {['User', 'Email', 'Trust Score', 'KYC', 'Status', 'Actions'].map(h => (
                          <th key={h} className="text-left text-xs font-semibold text-gray-500 px-4 py-3">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {users.map((u: any) => (
                        <tr key={u._id} className="hover:bg-gray-50 transition-colors">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#5B6CFF] to-[#3FAF7D] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                                {u.name?.[0]?.toUpperCase()}
                              </div>
                              <div>
                                <p className="text-sm font-medium text-gray-900">{u.name}</p>
                                <p className="text-xs text-gray-400 font-mono">{u._id?.slice(-8)}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-500">{u.email}</td>
                          <td className="px-4 py-3 text-sm font-bold text-gray-900">{u.creditScore ?? '—'}</td>
                          <td className="px-4 py-3">
                            <span className={cn('text-xs font-semibold px-2 py-1 rounded-full',
                              u.isKYCVerified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700')}>
                              {u.isKYCVerified ? 'Verified' : 'Pending'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <span className={cn('text-xs font-semibold px-2 py-1 rounded-full',
                              u.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700')}>
                              {u.isActive ? 'Active' : 'Frozen'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            {u.isActive ? (
                              <button onClick={() => handleFreeze(u._id)}
                                className="flex items-center gap-1 text-xs text-red-600 hover:bg-red-50 px-3 py-1.5 rounded-lg transition-colors font-medium">
                                <UserX className="w-3.5 h-3.5" /> Freeze
                              </button>
                            ) : (
                              <button onClick={() => handleActivate(u._id)}
                                className="flex items-center gap-1 text-xs text-green-700 hover:bg-green-50 px-3 py-1.5 rounded-lg transition-colors font-medium">
                                <UserCheck className="w-3.5 h-3.5" /> Activate
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-12 border border-gray-100 text-center">
                <Users className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                <p className="text-gray-400">No users found</p>
              </div>
            )}
          </motion.div>
        )}

        {/* Risk Alerts */}
        {tab === 'fraud' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            {fraudList.length > 0 ? (
              <div className="space-y-3">
                {fraudList.map((alert: any, i: number) => (
                  <div key={i} className="bg-white rounded-2xl p-5 border border-red-100 flex items-start gap-4">
                    <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0',
                      alert.severity === 'HIGH' ? 'bg-red-100' : 'bg-yellow-100')}>
                      <AlertTriangle className={cn('w-5 h-5', alert.severity === 'HIGH' ? 'text-red-600' : 'text-yellow-600')} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <p className="font-semibold text-gray-900 text-sm">{alert.type}</p>
                        <span className={cn('text-xs font-bold px-2 py-1 rounded-full',
                          alert.severity === 'HIGH' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700')}>
                          {alert.severity}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">{alert.description}</p>
                      {alert.createdAt && <p className="text-xs text-gray-400 mt-1">{formatDate(alert.createdAt)}</p>}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-12 border border-gray-100 text-center">
                <Package className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">No risk alerts</p>
                <p className="text-gray-400 text-sm mt-1">Platform looks healthy ✓</p>
              </div>
            )}
          </motion.div>
        )}
      </div>
    </Layout>
  );
};

export default AdminPage;
