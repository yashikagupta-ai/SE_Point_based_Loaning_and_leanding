import React, { useState, useEffect } from 'react';
import { Bell, Menu, Package } from 'lucide-react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import type { RootState } from '@/store';
import { notificationApi } from '@/services/api';

interface HeaderProps { onMenuClick: () => void; }

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  const { user } = useSelector((s: RootState) => s.auth);
  const navigate = useNavigate();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    notificationApi.getAll()
      .then(r => setUnread((r.data.data || []).filter((n: any) => !n.isRead).length))
      .catch(() => {});
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-gray-200 z-50 flex items-center px-4 gap-4">
      <button onClick={onMenuClick} className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors">
        <Menu className="w-5 h-5 text-gray-600" />
      </button>

      <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 flex-shrink-0 hover:opacity-80 transition-opacity">
        <div className="w-9 h-9 bg-gradient-to-br from-[#5B6CFF] to-[#3FAF7D] rounded-xl flex items-center justify-center shadow">
          <Package className="w-5 h-5 text-white" />
        </div>
        <span className="text-lg font-bold text-gray-900 hidden sm:block">
          Item<span className="text-[#5B6CFF]">Lend</span>
        </span>
      </button>

      <div className="flex-1" />

      <button className="relative p-2 rounded-lg hover:bg-gray-100 transition-colors">
        <Bell className="w-5 h-5 text-gray-600" />
        {unread > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 bg-[#5B6CFF] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
            {unread}
          </span>
        )}
      </button>

      <div className="flex items-center gap-2">
        <div className="w-9 h-9 bg-gradient-to-br from-[#5B6CFF] to-[#3FAF7D] rounded-full flex items-center justify-center text-white font-semibold text-sm">
          {user?.name?.[0]?.toUpperCase() || 'U'}
        </div>
        <div className="hidden sm:block">
          <p className="text-sm font-semibold text-gray-900 leading-none">{user?.name}</p>
          <p className="text-xs text-gray-500 capitalize mt-0.5">{user?.tier ?? 'Bronze'}</p>
        </div>
      </div>
    </header>
  );
};

export default Header;
